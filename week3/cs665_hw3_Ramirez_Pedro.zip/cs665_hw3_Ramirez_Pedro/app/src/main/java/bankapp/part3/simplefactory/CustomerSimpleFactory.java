package bankapp.part3.simplefactory;

public abstract class CustomerSimpleFactory {
    public abstract void describe();
}
