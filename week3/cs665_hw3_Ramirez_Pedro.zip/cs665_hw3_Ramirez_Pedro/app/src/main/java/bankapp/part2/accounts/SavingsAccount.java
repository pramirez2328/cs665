package bankapp.part2.accounts;

public class SavingsAccount {
    public void accountType() {
        System.out.print("**Basic Savings Account**");
    }
}
