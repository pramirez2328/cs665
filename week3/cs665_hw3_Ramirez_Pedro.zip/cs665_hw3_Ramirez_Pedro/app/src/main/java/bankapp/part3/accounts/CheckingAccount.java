package bankapp.part3.accounts;

public class CheckingAccount {
    public void accountType() {
        System.out.print("**Basic Checking Account**");
    }
}
