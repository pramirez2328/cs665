package bankapp.part1.accounts;

public class CheckingAccount {
    public void accountType() {
        System.out.print("**Basic Checking Account**");
    }
}
