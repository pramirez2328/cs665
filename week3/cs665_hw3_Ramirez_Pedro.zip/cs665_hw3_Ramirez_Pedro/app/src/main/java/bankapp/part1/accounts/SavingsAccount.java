package bankapp.part1.accounts;

public class SavingsAccount {
    public void accountType() {
        System.out.print("**Basic Savings Account**");
    }
}
