package bankapp.part3.factorymethod;

public abstract class CustomerFactoryMethod {
    public abstract void describe();
}
