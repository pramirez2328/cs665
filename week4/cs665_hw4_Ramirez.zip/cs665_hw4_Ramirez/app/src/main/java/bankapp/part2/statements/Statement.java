package bankapp.part2.statements;

public abstract class Statement {
    public abstract void printStatement();
}

