package bankapp.part3;

public interface IVerify {
    boolean verifyCustomer(Customer customer);
}

