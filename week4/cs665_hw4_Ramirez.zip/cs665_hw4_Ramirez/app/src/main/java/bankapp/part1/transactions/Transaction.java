package bankapp.part1.transactions;

public interface Transaction {
    String getDescription();
}
