package bankapp.part1.observer;

public interface Observer {
    void update(String message);
}
