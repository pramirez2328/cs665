package bankapp.part2.strategy;

public interface InterestStrategy {
    double calculateInterest(double balance, double rate);
}

